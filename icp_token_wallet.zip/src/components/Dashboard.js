import React, { useState, useEffect } from "react";
import { Actor, HttpAgent } from "@dfinity/agent";
import { idlFactory } from "../../declarations/token"; // Auto-generated
const agent = new HttpAgent();

const Dashboard = () => {
  const [balance, setBalance] = useState(0);
  const [principal, setPrincipal] = useState("");
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");

  const fetchBalance = async () => {
    const actor = Actor.createActor(idlFactory, { agent, canisterId: "token" });
    const balance = await actor.balanceOf(principal);
    setBalance(balance.toString());
  };

  const sendTokens = async () => {
    const actor = Actor.createActor(idlFactory, { agent, canisterId: "token" });
    await actor.transfer(recipient, BigInt(amount));
    alert("Tokens sent successfully!");
  };

  return (
    <div>
      <h1>ICP Wallet</h1>
      <input
        type="text"
        placeholder="Your Principal"
        value={principal}
        onChange={(e) => setPrincipal(e.target.value)}
      />
      <button onClick={fetchBalance}>Check Balance</button>
      <p>Balance: {balance}</p>

      <input
        type="text"
        placeholder="Recipient Principal"
        value={recipient}
        onChange={(e) => setRecipient(e.target.value)}
      />
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button onClick={sendTokens}>Send Tokens</button>
    </div>
  );
};

export default Dashboard;
